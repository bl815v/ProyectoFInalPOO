package model;

import java.util.ArrayList;

public class ListaDeHorarios {
	
	private ArrayList<Horarios>listadehorarios;
	
	

}
