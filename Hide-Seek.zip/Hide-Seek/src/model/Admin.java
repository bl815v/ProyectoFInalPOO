package model;

public class Admin extends Persona{

	public Admin(String user, String rol, String clave) {
		super(user, rol, clave);
		this.User=user;
		this.Rol=rol;
		this.clave=clave;
	}
	
	
}
	
	


